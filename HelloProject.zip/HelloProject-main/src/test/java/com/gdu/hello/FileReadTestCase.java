package com.gdu.hello;

import org.junit.Test;

public class FileReadTestCase {

  @Test
  public void 파일읽기테스트() throws Exception {
    
    // 배열을 그대로 사용하시오.
    String[] numbers = {"1", "2", "3", "4", "5"};
    
    // 추가 코드를 작성하시오.
    
    
  }
  
}
